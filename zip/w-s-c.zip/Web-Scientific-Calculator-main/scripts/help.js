var backButton = document.getElementById("goBack");
backButton.onclick = () => {
	window.location.replace("../index.html");
}

var backButton1 = document.getElementById("goBack1");
backButton1.onclick = () => {
	window.location.replace("../index.html");
}